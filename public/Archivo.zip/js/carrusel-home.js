$('#owl-home').owlCarousel({
  nav: true,
  items: 1,
  margin: 56,

  dots:true,
  autoplay:true,
  autoplayTimeout:6000
});


$(".owl-prev").addClass("next2").text("");
$(".owl-next").addClass("prev2").text("");
